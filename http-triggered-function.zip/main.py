import functions_framework
import csv
import json
from flask import jsonify
from google.cloud import storage

def generate_html_table(data, json_data):
    if isinstance(data, list) and all(isinstance(item, dict) for item in data):
        headers = list(data[0].keys())
    else:
        return "<p>Invalid data format</p>"

    html_table = "<table border='1'>"
    html_table += "<tr>"
    for header in headers:
        html_table += f"<th>{header}</th>"
    html_table += "</tr>"
    for row in data:
        html_table += "<tr>"
        for value in row.values():
            html_table += f"<td>{value}</td>"
        html_table += "</tr>"
    html_table += "</table>"

    # Embed JSON data within HTML using a <script> tag
    html_script = f"<script>var jsonData = {json_data};</script>"

    return f"{html_table}{html_script}"

@functions_framework.http
def hello_http(request):

    bucket_name = 'apps_data_input'
    file_name = 'googleplaystore.csv'

    # Initialize a client to interact with Cloud Storage
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucket_name)

    # Download the CSV file from Cloud Storage
    blob = bucket.blob(file_name)
    csv_data = blob.download_as_string().decode('utf-8')

    # Parse the CSV data
    csv_rows = csv.reader(csv_data.splitlines())
    headers = next(csv_rows)
    data = [dict(zip(headers, row)) for row in csv_rows]
    
    # Generate HTML table
    html_table = generate_html_table(headers, data)

    # Generate JSON response
    json_response = json.dumps(data)

    # Generate HTML response with embedded JSON
    html_response = generate_html_table(data, json_response)
    
    # Return HTML response
    return html_response
    